class MEvent( object ):
    """
    Generic event to use with MEventDispatch.
    """

    def __init__(self, event_type):
        """
        The constructor accepts an event type as string and a custom data
        """
        self._type = event_type

    @property
    def type(self):
        """
        Returns the event type
        """
        return self._type

    @property
    def data(self):
        """
        Returns the data associated to the event
        """
        return self._data
