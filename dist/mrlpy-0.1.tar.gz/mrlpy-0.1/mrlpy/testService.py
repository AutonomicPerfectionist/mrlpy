from mservice import MService

class TestService(MService):
	def __init__(self, name):
		super(TestService, self).__init__(name)
