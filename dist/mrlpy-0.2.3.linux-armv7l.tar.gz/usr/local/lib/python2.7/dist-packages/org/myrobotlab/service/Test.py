class Test(object):
	def __init__(self, name):
		print "Test completed: name = " + str(name)
